console.log('Optimization initialized') //eslint-disable-line
$('.lazy').Lazy({
  visibleOnly: true,
});
