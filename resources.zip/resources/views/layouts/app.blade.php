<!doctype html>
<html @php(language_attributes())>
  @include('partials.head')
  <body @php(body_class()) data-spy="scroll" data-target="#navbar" data-offset="250">
    @php(do_action('get_header'))

    @yield('content')


    @php(do_action('get_footer'))

    @include('partials.footer')
    @php(wp_footer())
  </body>
</html>
