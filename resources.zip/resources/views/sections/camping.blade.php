<div class="mobile-title mobile-title--purple-light">
  Camping
</div>

<div class="section-mf section-mf--border-blue section-mf--multiple">
  <section class="camping" id="camping" style="background-image: url('{{ $camping_background }}')">
    <section class="title title--orientation-left title--off-pink title--md">
      <div class="title__wrapper title__wrapper--border-blue title__wrapper--bg-purple">
        <h1 class="title__content">Camping</h1>
      </div>
    </section>

    <div class="container">
      <img src="{{ get_template_directory_uri() . '/assets/icons/tents.svg' }}" alt="Tents" class="camping__tents">
      <div class="card">
        <div class="camping-card__header">
          <div class="camping-card__name">{{ the_field('camping_name')}} </div>
          <div class="camping-card__title">{{ the_field('camping_title') }}</div>
        </div>
        <div class="camping-card__body">
          {{ the_field('camping_content') }}
        </div>
        <a href="https://www.eventbrite.com/e/float-fest-2018-tickets-41197844863" target="_blank" class="card__buy">Buy Now</a>
      </div>
    </div>
  </section>
