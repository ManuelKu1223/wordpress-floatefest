<section class="floating" id="float" style="background-image: url('{{ $floating_background }}')">
  <img src="{{ get_template_directory_uri() . '/assets/icons/floating-logo.png' }}" alt="Floating at Float Fest" class="floating__logo">
</section>
