<div class="mobile-title mobile-title--purple">
  Lineup
</div>

<section class="artists section-mf lazy" id="lineup" data-src="{{ get_template_directory_uri() . '/assets/icons/lineup-background-2.jpg' }}">
  <section class="title title--orientation-right title--off-pink title--sm">
    <div class="title__wrapper title__wrapper--border-blue title__wrapper--bg-purple">
      <h1 class="title__content">Lineup</h1>
    </div>
  </section>

  <div class="artists__list">
    @if(have_rows('artists', 'options'))
      @while(have_rows('artists', 'options'))
        @php
          the_row();
          $band_name = get_sub_field('name');
          $bw_image = get_sub_field('bw_image');
          $color_image = get_sub_field('colour_image');
        @endphp

        @if($band_name === 'banner')
          <div class="banner">
            <img src="{{ App::get_image_by_id($bw_image, 'large') }}" alt="{{ $band_name }}" class="artist__bw lazy">
          </div>
        @else
          <div class="artist">
            <img src="{{ App::get_image_by_id($bw_image, 'large') }}" alt="{{ $band_name }}" class="artist__bw lazy">
            <img data-src="{{ App::get_image_by_id($color_image, 'large') }}" alt="{{ $band_name }}" class="artist__color lazy">
          </div>
        @endif
      @endwhile
    @endif
  </div>
</section>
