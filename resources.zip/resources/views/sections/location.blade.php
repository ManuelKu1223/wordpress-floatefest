<div class="mobile-title mobile-title--purple-light">
  Information
</div>


<div class="section-mf section-mf--multiple section-mf--border-teal">

  <section class="location" id="location" style="background-image: url('{{ $directions_background }}')">
    <section class="title title--orientation-left title--off-teal title--location">
      <div class="title__wrapper title__wrapper--border-yellow title__wrapper--bg-purple">
        <h1 class="title__content">Information</h1>
      </div>
    </section>

    <section class="title title--orientation-left title--small">
      <div class="title__wrapper title__wrapper--bg-pink title__wrapper--small title__wrapper--shadow-left-yellow">
        <img src="{{ get_template_directory_uri() . '/assets/icons/plant-1.svg'}}" alt="Plant" class="title__plant">
        <h2 class="title__content title__content--small">Location</h2>
      </div>
    </section>

    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3460.5657366749483!2d-97.8728649848895!3d29.847954281954177!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x865cabe23e4de175%3A0xb34dad064b7839d0!2s601+Dupuy+Ranch+Rd%2C+Martindale%2C+TX+78655!5e0!3m2!1spl!2sus!4v1481488105939" frameborder="0" style="border:0" allowfullscreen class="location__map"></iframe>
    <div class="location__address">
      <div class="location__address__content">
        Cool River Ranch | 601 DUPuy ranch rd | Martindale, tx 78655
      </div>
    </div>

    <div class="container">
      <div class="location__directions">
        <div class="card card--half">
          <div class="card__header">
            <div class="card__name card__name--full card__name--small">Coming from Austin</div>
          </div>
          <div class="card__body card__body--directions">
            <p>South on I-35 to San Marcos</p>
            <p>Head east at HWY 123 exit</p>
            <p>First red light go left</p>
            <p>Follow 621 to Scull Road and go left</p>
            <p>Turn left into venue at the first curve</p>
          </div>
        </div>
        <div class="card card--half">
          <div class="card__header">
            <div class="card__name card__name--full card__name--small">Coming from San Antonio</div>
          </div>
          <div class="card__body card__body--directions">
            <p>North on I-35 to San Marcos</p>
            <p>Head east at HWY 123 exit</p>
            <p>First red light go left</p>
            <p>Follow 621 to Scull Road and go left</p>
            <p>Turn left into venue at the first curve</p>
          </div>
        </div>
      </div>
    </div>
  </section>
