<div class="mobile-title mobile-title--purple-light" data-target="tickets">
  Buy Tickets
</div>
<section id="tickets" class="tickets section-mf lazy" data-src="{{ $tickets_background }}">
  <section class="title title--orientation-left title--off-teal">
    <div class="title__wrapper title__wrapper--border-yellow title__wrapper--bg-purple">
      <h1 class="title__content">Buy Tickets</h1>
    </div>
  </section>

  <div class="container">
    <div class="row">
      <div class="col-md-12">
        <div class="tickets__list">

          @foreach($tickets as $ticket)
            @include('partials.ticket-box')
          @endforeach


        </div>
      </div>
    </div>
  </div>

  <img src="{{ get_template_directory_uri() . '/assets/icons/rings-tickets.svg' }}" alt="Floating Rings" class="tickets__rings">

</section>
