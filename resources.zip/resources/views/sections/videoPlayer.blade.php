<div id="videoPlayer">
  <div class="vp-overlay"></div>
  <div class="vp-container" id="currVideo">
  </div>
</div>
