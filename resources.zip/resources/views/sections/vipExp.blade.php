<div class="mobile-title mobile-title--purple">
  Vip Experience
</div>


<section class="vip vip--exp section-mf lazy" id="vip" data-src="{{ $vip_background }}">
  <section class="title title--orientation-right title--off-pink title--sllg title--vip">
    <div class="title__wrapper title__wrapper--border-yellow title__wrapper--bg-purple">
      <h1 class="title__content">VIP Experience</h1>
    </div>
  </section>

  <div class="vip-exp">
    <div class="vip__cards">
      @foreach(App::get_tickets_by_category('VIP') as $ticket)
        @php
          $ticket_options = get_field('ticket_options', $ticket['ID']);
          $ticket_sold_out = false;
          $ticket_title = get_field('ticket_title', $ticket['ID']);
          $ticket_new = false;
          $ticket_tiers = have_rows('ticket_tiers', $ticket['ID']);
          if (is_array($ticket_options)) {
            $ticket_sold_out = in_array('sold', $ticket_options) ? true : false;
            $ticket_new = in_array('new', $ticket_options) ? true : false;
          }
        @endphp
        <div class="card ticket-box card--vip">
          <div class="card__header {{ $ticket_new ? 'ticket-box__header--new' : '' }}">
            <div class="card__name card__name--vip-exp">{{ get_field('vip_ticket_name', $ticket['ID']) }}</div>
            @if(have_rows('ticket_tiers', $ticket['ID']))
              <div class="card__tiers card__tiers--vip-exp">
              @while(have_rows('ticket_tiers', $ticket['ID']))
                @php(the_row())
                  @include('tickets.tiers')
              @endwhile
              </div>
            @else
              <div class="card__price card__price--vip-exp">{{ get_field('ticket_price', $ticket['ID']) }}</div>
            @endif

            @if(!$ticket_sold_out)
              <a href="{{ get_field('buy_link', $ticket['ID']) }}" target="_blank" class="card__buy card__buy--header card__buy--vip-exp {{ $ticket_tiers ? 'card__buy--tiers' : '' }}">Buy Now</a>
            @else
              <div class="card__buy card__buy--header card__buy--sold card__buy--vip-exp {{ $ticket_tiers ? 'card__buy--tiers' : '' }}">Sold Out</div>
            @endif
          </div>
          <div class="ticket-box__body card__body--vip card__body--vip-exp">
            <div class="vip-exp-subtitle">
              <div class="card__subtitle card__subtitle--vip-exp">{{ get_field('vip_ticket_title', $ticket['ID']) }}</div>
            @if(have_rows('vip_ticket_content', $ticket['ID']))
              @while(have_rows('vip_ticket_content', $ticket['ID']))
                @php(the_row())

                @if(get_row_layout() == 'large_content')
                    <div class="card__subtitle card__subtitle--vip-exp-nd">
                      {{ the_sub_field('content')}}
                    </div>
                  </div>
                @else
                  @include('tickets.' . get_row_layout())
                @endif

              @endwhile
            @endif
          </div>
          @if($ticket_title)
            <div class="ticket-box__more ticket-box__more--vip">
              More Info
            </div>
          @endif
        </div>
      @endforeach
    </div>

    @php($gallery = get_field('vip_experience_images') )
    @if($gallery)
      <div class="vip-exp__side">
        <div class="vip-exp__gallery">
          @foreach($gallery as $image)
            @php
              $title = $image['title'];
              $full_image_url = $image['sizes']['large'];
            @endphp
            <div class="photo__wrapper photo__wrapper--large">
              <img class="photo photo--large" data-lazy="{{ $full_image_url }}" alt="{{ $title }}" title="{{ $title }}">
            </div>
          @endforeach
        </div>
      </div>
    @endif
  </div>
  <div class="vip__grounded__wrapper">
    <div class="vip__grounded">
      <img src="{{ get_template_directory_uri() . '/assets/images/grounded.png'}}" alt="Supporting Grounded in Music " class="vip__grounded__image">
    </div>
  </div>


</section>
