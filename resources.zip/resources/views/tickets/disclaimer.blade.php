<div class="ticket__disclaimer">
  {{ get_field('ticket_disclaimer_content', $ticket['ID']) }}
</div>
