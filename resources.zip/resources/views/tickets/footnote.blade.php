<div class="card__footnote">
  {{ the_sub_field('content') }}
</div>
