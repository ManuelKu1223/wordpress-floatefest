<article class="ticket-box__description">
  <div class="ticket-box__description__inner">
    {{ the_sub_field('content')}}
  </div>
</article>
