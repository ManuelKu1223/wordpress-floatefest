<div class="card__subtitle card__subtitle--long card__subtitle--tickets">
  {!! get_sub_field('content') !!}
</div>
