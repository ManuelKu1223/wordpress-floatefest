<article class="ticket-box__description ticket-box__description--vip">
  <h1 class="ticket-box__description__title">{{ the_sub_field('title') }}</h1>
  <div class="ticket-box__description__inner">
    {{ the_sub_field('content')}}
  </div>
</article>
